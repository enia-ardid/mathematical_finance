Main document: main.tex. Build with latexmk -pdf main.tex or tectonic --reruns 3 main.tex.
This bundle includes aggregate results and protocol records; no raw market data.
Numerical reproduction requires the accompanying repository and documented data snapshots.
